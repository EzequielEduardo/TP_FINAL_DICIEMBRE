#include<iostream>
#include<clocale>
#include<cstdlib>
#include<cstring>
#include <cstdio>
#include<string.h>
#include "Fecha.h"
#include "Cliente.h"
#include "ClienteNegocio.h"
#include "ClienteFile.h"
#include "ClienteVista.h"
#include "Proveedor.h"
#include "MenuPrincipal.h"
#include"TransaxinventarioNegocio.h"
#include"Articulo.h"
using namespace std;


int main()
{

MenuPrincipal mainMenu;
mainMenu.menuPrincipal();


return 0;
}
