#define FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#ifndef MENUPRINCIPAL_H
#define MENUPRINCIPAL_H

class MenuPrincipal
{

	private:


	public:


    void menuPrincipal();
    void submenuMaestros();
    void submenuInventarios();
	void submenuCompras();
	void submenuVentas();
};

#endif // MENUPRINCIPAL_H
