#define FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#ifndef PROVEEDORVISTA_H
#define PROVEEDORVISTA_H
#include"Proveedor.h"
#include"ProveedorNegocio.h"

class ProveedorVista
{

	private:


	public:
    void menuProveedores();
	bool cargarProveedores();
	void mostrarProveedores();


};


#endif // PROVEEDORVISTA_H
