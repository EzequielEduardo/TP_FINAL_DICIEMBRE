#define FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#ifndef ARTICULOVISTA_H
#define ARTICULOVISTA_H


class ArticuloVista
{
	public:
		bool cargarArticulos();
		void mostrarArticulos();
		void menuArticulos();
		float askNewPrice();
		void messageCargaOK();
		void messageCargaNotOK();
	private:
};

#endif // ARTICULOVISTA_H
