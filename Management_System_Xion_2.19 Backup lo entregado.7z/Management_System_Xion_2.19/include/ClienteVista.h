#define FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#ifndef CLIENTEVISTA_H
#define CLIENTEVISTA_H
#include "ClienteNegocio.h"
#include "Cliente.h"

class ClienteVista
{

	private:


	public:


    void menuClientes();
	bool cargarCliente();
	void mostrarClientes();


};

#endif // CLIENTEVISTA_H
