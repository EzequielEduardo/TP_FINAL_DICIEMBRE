#define FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#ifndef EMPLEADOVISTA_H
#define EMPLEADOVISTA_H


#include"EmpleadoNegocio.h"

#include"Empleado.h"
class EmpleadoVista
{

	private:

	public:

    void menuEmpleados();
	bool cargarEmpleados();
	void mostrarEmpleados();

};

#endif // EMPLEADOVISTA_H
