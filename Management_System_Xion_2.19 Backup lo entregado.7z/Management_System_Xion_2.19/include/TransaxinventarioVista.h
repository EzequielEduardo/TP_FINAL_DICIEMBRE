#define FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#ifndef TRANSAXINVENTARIOVISTA_H
#define TRANSAXINVENTARIOVISTA_H


class TransaxinventarioVista
{
	private:


	public:

	void MostrarInventario();
	void MostrarStockxFecha();
	void MostrarInventarioxCategoria();
	void MostrarInventarioxMarca();
};

#endif // TRANSAXINVENTARIOVISTA_H

