#ifndef VENTAVISTA_H
#define VENTAVISTA_H


class VentaVista
{
    private:


	public:


    void menuVentas();
	bool cargarVentas();
	bool mostrarVentas();
	void MostrarVtasxFecha();
	void ListarVtasxFactura();
	void messageAnulacionOK();
	void messageAnulacionNotOK();
	void messageReversoAnulacionOK();
	int PideNewQFacturaVtas();
	void messageFacturaModifOK();

};

#endif // VENTAVISTA_H
