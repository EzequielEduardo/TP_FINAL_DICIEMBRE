#define FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#ifndef EMPLEADOFILE_H
#define EMPLEADOFILE_H


class EmpleadoFile
{
	private:

	public:

		bool grabarEnDisco(Empleado );
        Empleado* obtener_Datos_de_Empleados();
        int  cantidadDeDatosGrabados();

};


#endif // EMPLEADOFILE_H
